﻿How to run program

To run the program it must be complied as “ gcc mutex2.c -lpthread”
then ran as “./a.out arg1 arg2”


The program takes 2 arguments(the first being number of philosophers and the second being how many times he/she will eat before exiting)

Once the program is executed a list of philosophers will print out as columns. The rows will update periodically and represent each philosophers status as ‘H’(Hungry), ‘E’(Eating), and ‘T’(Thinking).

The program will run until every philosopher has eaten and will end with all of them in the thinking state.
