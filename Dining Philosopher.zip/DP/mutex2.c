#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Samuel Evans 
// 4/12/2021


sem_t chopstick[0];
sem_t mutex;
int num;
int eat;
char status[]={};
void printstatus(){
    printf("\n");
    for(int i = 0; i<=num;i++){
        printf(" %c ", status[i]);
        
    }
}
void *Philosopher(void *arg){
    int j;
    long int i = (long int) arg;
    while(j<=eat){
        if(j == eat){
            pthread_exit(NULL);
        }
        else{
            
            //hungry state
            status[i]='H';
            //printstatus();
            sleep(1);

            //grab chopsticks
            //locking mutex
            
            if(status[i] % 2 == 1){
                sem_wait(&mutex);
                sem_wait(&chopstick[i]); //left chop
                sleep(1);
                sem_wait(&chopstick[(i + 1)%5]); //right chop
            

            }
            else{
                sem_wait(&mutex);
                sem_wait(&chopstick[(i + 1)%5]); //right chop
                sleep(1);
                sem_wait(&chopstick[i]); //left shop
                
                
            }
            
            //Eating status
            status[i] = 'E';
            printstatus();
            sleep(1);

            //putdown chopsticks
        
            if(status[i] % 2 == 1){
                
                
                sem_post(&chopstick[i]);
                sleep(1);
                sem_post(&chopstick[(i+1)%5]);
                sem_post(&mutex);
                
                
            

            }
            else{
                
                sem_post(&chopstick[(i+1)%5]);
                sleep(1);
                sem_post(&chopstick[i]);
                sem_post(&mutex);
                
                
            
                
            }
            //unlocking mutex
            //sem_post(&mutex);

            //Thinking status 
            status[i] = 'T';
            printstatus();
            sleep(1);
            j++;
            //pthread_exit(NULL);
        }
    }


}


int main(int argc, char *argv[]){
    int long i,j;
    //int num;
    //int eat;
   
    if (argc != 3){
        printf("Usage: %s <niters>\n", argv[0]);
        exit(0);
    }
    num = atoi(argv[1]); //number of philosophers
    printf("There are %d philosophers." , num);
    eat = atoi(argv[2]);
    chopstick[num];
    status[num+1];
    pthread_t phil[num];
    //init semaphores
    for(i = 0; i<num+1; i++){
        sem_init(&chopstick[i], 0, 1);
    }
    //init mutex
    sem_init(&mutex, 0, 1);
    printf("\n");
    for(i=1; i<num+1; i++){
        printf("P[%ld] ", i);
    }
    //create threads of philosophers
    for(i=0; i<=num; i++){
        pthread_create(&phil[i], NULL, Philosopher, (void *)i);
    }
    //join the threads 
    for(j=0; j<=num; j++){
        pthread_join(phil[j], NULL);
    }
}




