Name: Samuel Evans
Louisiana Tech University
CSC-222-002(Systems Programming)
Final Project

Tech Shell Assignment: *C program that simulates a linux command line environment 
                       *Current version supports 3 built-in commands(cd, pwd, exit)
                       *I/O redirection 
                       *Non built-in commands
                       *Error handling

